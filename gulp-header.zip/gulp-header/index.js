/* jshint node: true */
'use strict';

var path = require('path');

var es = require('event-stream');
var gutil = require('gulp-util');

var headerPlugin = function(headerText, data) {
  headerText = headerText || '';
  return es.map(function(file, cb) {

    var fileName = file.path.split('/').pop().replace('.html','');
    var scriptOpen = '<script type="text/template" id="'+fileName.toLowerCase()+'-viewtpl">';

    file.contents = Buffer.concat([
      new Buffer(scriptOpen, data),
      file.contents,
      new Buffer('</script>', data)
    ]);
    cb(null, file);
  });
};

module.exports = headerPlugin;
